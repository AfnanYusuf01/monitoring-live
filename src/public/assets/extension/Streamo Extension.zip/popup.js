document.addEventListener("DOMContentLoaded", function () {
  const t = document.getElementById("accessTokenInput"),
    a = document.getElementById("saveTokenBtn"),
    i = document.getElementById("addAccountBtn"),
    l = document.getElementById("syncDataBtn"),
    o = document.getElementById("status");
  function u(e, t = "info") {
    (o.textContent = e),
      (o.className = "status " + t),
      setTimeout(() => {
        (o.textContent = ""), (o.className = "status");
      }, 5e3);
  }
  function m(e, t = !1) {
    var a = document.querySelector(".notification");
    a && a.remove();
    const o = document.createElement("div");
    (o.className = "notification " + (t ? "error" : "")),
      (o.textContent = e),
      document.body.appendChild(o),
      setTimeout(() => {
        o.parentNode && o.parentNode.removeChild(o);
      }, 4e3);
  }
  function r() {
    var e = t.value.trim();
    if (e) {
      (a.disabled = !0), (a.textContent = "Saving...");
      try {
        localStorage.setItem("shopee_access_token", e),
          u("Access code saved successfully!", "success"),
          m("Access code saved!");
      } catch (e) {
        console.error("Error saving access code:", e),
          u("Failed to save access code", "error"),
          m("Failed to save access code", !0);
      } finally {
        (a.disabled = !1), (a.textContent = "Save");
      }
    } else u("Please enter an access code", "error");
  }
  function f() {
    return t.value.trim() || null;
  }
  a.addEventListener("click", r),
    i.addEventListener("click", async function () {
      try {
        (i.disabled = !0),
          (i.textContent = "Processing..."),
          u("Extracting cookies and adding account...", "info");
        var e = f();
        if (!e) throw new Error("Please enter and save your access code first");
        var [t] = await chrome.tabs.query({ active: !0, currentWindow: !0 });
        if (!t) throw new Error("No active tab found");
        if (!new URL(t.url).hostname.includes("shopee."))
          throw new Error("Please navigate to a Shopee website first");
        var a = await chrome.cookies.getAll({ url: t.url });
        if (!a || 0 === a.length)
          throw new Error("No cookies found for this Shopee site");
        var o,
          r,
          n = a.map((e) => e.name + "=" + e.value).join("; "),
          s = await fetch("https://streamo.id/api/akun/create", {
            method: "POST",
            headers: { "Content-Type": "application/json", access_token: e },
            body: JSON.stringify({ cookie: n }),
          });
        if (!s.ok)
          throw (
            ((r = await s.text()),
            new Error(`Server error: ${s.status} - ` + r))
          );
        (o = await s.json()),
          u("Account successfully added to server!", "success"),
          m("Account added successfully!"),
          console.log("Server response:", o);
      } catch (e) {
        console.error("Error adding account:", e),
          u("Failed to add account: " + e.message, "error"),
          m("Failed: " + e.message, !0);
      } finally {
        (i.disabled = !1), (i.textContent = "Add Account to Server");
      }
    }),
    l.addEventListener("click", async function () {
      try {
        (l.disabled = !0),
          (l.textContent = "Sending..."),
          u("Sending report data to server...", "info");
        var e = f();
        if (!e) throw new Error("Please enter and save your access code first");
        var [t] = await chrome.tabs.query({ active: !0, currentWindow: !0 });
        if (!t) throw new Error("No active tab found");
        var a = new URL(t.url);
        if (
          !a.hostname.includes("shopee.") ||
          !a.href.includes("affiliate") ||
          !a.href.includes("dashboard")
        )
          throw new Error(
            "Please navigate to Shopee affiliate dashboard first"
          );
        var o = await chrome.tabs.sendMessage(t.id, {
          action: "getInterceptedData",
        });
        if (!o || !o.data || 0 === o.data.length)
          throw new Error(
            "No affiliate data captured yet. Please refresh the dashboard and try again."
          );
        var r = o.data[o.data.length - 1];
        if (!r.data || !r.data.data || !r.data.data.list)
          throw new Error("Invalid data format received from dashboard");
        var n = r.data.data.list;
        const d = (await chrome.cookies.getAll({ url: t.url }))
          .map((e) => e.name + "=" + e.value)
          .join("; ");
        var s,
          i = n.map((e) => ({
            cookie: d,
            ymd: e.ymd || new Date().toISOString().split("T")[0],
            clicks: e.clicks || 0,
            cv_by_order: e.cv_by_order || 0,
            order_cvr: e.order_cvr || 0,
            order_amount: e.order_amount || 0,
            total_commission: e.total_commission || 0,
            total_income: e.total_income || 0,
            new_buyer: e.new_buyer || 0,
            program_type: e.program_type || 1,
            item_sold: e.item_sold || 0,
            est_commission: String(e.est_commission || "0"),
            est_income: String(e.est_income || "0"),
          })),
          c = await fetch("https://streamo.id/api/affiliate-stats", {
            method: "POST",
            headers: { "Content-Type": "application/json", access_token: e },
            body: JSON.stringify(i),
          });
        if (!c.ok)
          throw (
            ((s = await c.text()),
            new Error(`Server error: ${c.status} - ` + s))
          );
        u(`Report sent successfully! (${i.length} records)`, "success"),
          m(`Report sent: ${i.length} records`);
      } catch (e) {
        console.error("Error sending report:", e),
          u("Failed to send report: " + e.message, "error"),
          m("Failed: " + e.message, !0);
      } finally {
        (l.disabled = !1), (l.textContent = "Send Daily Performance");
      }
    }),
    t.addEventListener("keypress", function (e) {
      "Enter" === e.key && r();
    });
  try {
    var e = localStorage.getItem("shopee_access_token");
    if (e) t.value = e;
  } catch (e) {
    console.error("Error loading access code:", e);
  }
  chrome.tabs.query({ active: !0, currentWindow: !0 }, function (e) {
    e[0] &&
      ((e = new URL(e[0].url)).hostname.includes("shopee.")
        ? e.href.includes("affiliate") && e.href.includes("dashboard")
          ? u("Ready to send affiliate reports", "info")
          : u("Ready to add Shopee account", "info")
        : u("Navigate to Shopee website to start", "error"));
  });
});
