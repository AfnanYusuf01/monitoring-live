let interceptedData = [];
function showNotification(e, t) {
  const o = document.createElement("div");
  (o.className = "shopee-extension-notification"),
    (o.innerHTML = `
  <div style="
    position: fixed;
    top: 20px;
    right: 20px;
    background-color: #4caf50;
    color: white;
    padding: 15px 20px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    z-index: 10000;
    font-family: Arial, sans-serif;
    font-size: 14px;
    max-width: 350px;
    animation: slideInFromRight 0.3s ease-in-out;
  ">
    <div style="font-weight: bold; margin-bottom: 5px;">${e}</div>
    <div>${t}</div>
  </div>
`),
    document.getElementById("shopee-extension-styles") ||
      (((e = document.createElement("style")).id = "shopee-extension-styles"),
      (e.innerHTML = `
    @keyframes slideInFromRight {
      from {
        transform: translateX(100%);
        opacity: 0;
      }
      to {
        transform: translateX(0);
        opacity: 1;
      }
    }
  `),
      document.head.appendChild(e)),
    document.body.appendChild(o),
    setTimeout(() => {
      o.parentNode && o.parentNode.removeChild(o);
    }, 4e3);
}
function injectNetworkInterceptor() {
  var e;
  window.location.href.includes("affiliate.shopee") &&
    window.location.href.includes("/dashboard") &&
    (((e = document.createElement("script")).src = chrome.runtime.getURL(
      "network-interceptor.js"
    )),
    (e.onload = function () {
      this.remove(),
        console.log(
          "Network interceptor injected into Shopee affiliate dashboard"
        );
    }),
    (document.head || document.documentElement).appendChild(e),
    window.addEventListener("shopeeDataIntercepted", function (e) {
      interceptedData.push(e.detail),
        console.log("Data intercepted by content script:", e.detail),
        showNotification("🎯 Data Captured!", "Request recorded");
    }));
}
chrome.runtime.onMessage.addListener((e, t, o) => {
  "getCookies" === e.action && o({ cookies: document.cookie }),
    "getPageInfo" === e.action &&
      o({
        url: window.location.href,
        title: document.title,
        domain: window.location.hostname,
      }),
    "getInterceptedData" === e.action &&
      o({
        data: window.getShopeeInterceptedData
          ? window.getShopeeInterceptedData()
          : interceptedData,
      }),
    "clearInterceptedData" === e.action &&
      (window.clearShopeeInterceptedData && window.clearShopeeInterceptedData(),
      (interceptedData = []),
      o({ success: !0 }));
}),
  injectNetworkInterceptor();
let currentUrl = window.location.href;
const observer = new MutationObserver(() => {
  window.location.href !== currentUrl &&
    ((currentUrl = window.location.href),
    setTimeout(injectNetworkInterceptor, 1e3));
});
observer.observe(document.body, { childList: !0, subtree: !0 }),
  console.log(
    "Shopee Cookie Extractor content script loaded on:",
    window.location.hostname
  );
