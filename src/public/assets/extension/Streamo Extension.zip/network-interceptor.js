!(function () {
  "use strict";
  window.shopeeInterceptedData = window.shopeeInterceptedData || [];
  const a = /\/api\/v3\/dashboard\/detail/,
    r = window.fetch,
    n =
      ((window.fetch = async function (...e) {
        var t = await r.apply(this, e),
          e = e[0];
        if ("string" == typeof e && a.test(e))
          try {
            var s = await t.clone().json(),
              n = document.cookie,
              o = {
                url: e,
                timestamp: new Date().toISOString(),
                status: t.status,
                statusText: t.statusText,
                headers: Object.fromEntries(t.headers.entries()),
                requestCookies: n,
                data: s,
              };
            window.shopeeInterceptedData.push(o),
              10 < window.shopeeInterceptedData.length &&
                (window.shopeeInterceptedData =
                  window.shopeeInterceptedData.slice(-10)),
              window.dispatchEvent(
                new CustomEvent("shopeeDataIntercepted", { detail: o })
              ),
              console.log("Shopee API response intercepted:", e, s);
          } catch (e) {
            console.error("Error intercepting Shopee API response:", e);
          }
        return t;
      }),
      XMLHttpRequest.prototype.open),
    t = XMLHttpRequest.prototype.send;
  (XMLHttpRequest.prototype.open = function (e, t, ...s) {
    return (this._url = t), n.apply(this, [e, t, ...s]);
  }),
    (XMLHttpRequest.prototype.send = function (...e) {
      if (this._url && a.test(this._url)) {
        const o = this.onreadystatechange;
        this.onreadystatechange = function () {
          if (4 === this.readyState && 200 <= this.status && this.status < 300)
            try {
              var e = JSON.parse(this.responseText),
                t = document.cookie;
              const n = {
                url: this._url,
                timestamp: new Date().toISOString(),
                status: this.status,
                statusText: this.statusText,
                headers: {},
                requestCookies: t,
                data: e,
              };
              var s = this.getAllResponseHeaders();
              s &&
                s.split("\r\n").forEach((e) => {
                  e = e.split(": ");
                  2 === e.length && (n.headers[e[0]] = e[1]);
                }),
                window.shopeeInterceptedData.push(n),
                10 < window.shopeeInterceptedData.length &&
                  (window.shopeeInterceptedData =
                    window.shopeeInterceptedData.slice(-10)),
                window.dispatchEvent(
                  new CustomEvent("shopeeDataIntercepted", { detail: n })
                ),
                console.log(
                  "Shopee API response intercepted (XHR):",
                  this._url,
                  e
                );
            } catch (e) {
              console.error("Error intercepting XHR Shopee API response:", e);
            }
          if (o) return o.apply(this, arguments);
        };
      }
      return t.apply(this, e);
    }),
    (window.getShopeeInterceptedData = function () {
      return window.shopeeInterceptedData || [];
    }),
    (window.clearShopeeInterceptedData = function () {
      window.shopeeInterceptedData = [];
    }),
    console.log("Shopee network interceptor injected successfully");
})();
